from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import requests
import joblib  # For saving models
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)

# Default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Initialize the DAG
dag = DAG(
    'model_retraining_dag',
    default_args=default_args,
    description='DAG for periodic model retraining',
    schedule_interval='@daily',
)

# Task 1: Fetch new data from an API
def fetch_data_task(ti):
    try:
        logging.info("Fetching new data...")
        url = "https://financialmodelingprep.com/api/v3/stock/list?apikey=your_fmp_key"
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        # Store data using Airflow's XCom for the next task
        ti.xcom_push(key='fetched_data', value=data)
        logging.info("Data fetched successfully.")
    except Exception as e:
        logging.error(f"Error fetching data: {e}")
        raise

fetch_data = PythonOperator(
    task_id='fetch_data',
    python_callable=fetch_data_task,
    dag=dag,
)

# Task 2: Retrain the model using the fetched data
def retrain_model_task(ti):
    try:
        logging.info("Retraining the model...")
        # Retrieve the data from XCom
        data = ti.xcom_pull(key='fetched_data', task_ids='fetch_data')

        # Example: Train a simple model (replace with real logic)
        from sklearn.linear_model import LinearRegression
        model = LinearRegression()

        # Extract dummy training data from the fetched data
        X = [[item['price']] for item in data[:10]]
        y = [item['price'] for item in data[:10]]
        model.fit(X, y)

        # Save the model
        joblib.dump(model, '/tmp/stock_model.pkl')
        logging.info("Model retrained and saved successfully.")
    except Exception as e:
        logging.error(f"Error retraining model: {e}")
        raise

retrain_model = PythonOperator(
    task_id='retrain_model',
    python_callable=retrain_model_task,
    dag=dag,
)

# Define the task dependencies
fetch_data >> retrain_model
