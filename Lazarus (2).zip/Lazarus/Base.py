# STOCK PREDICTION MODEL - CONSOLIDATED AND ENHANCED VERSION
# ============================================================
# Feature Checklist:
# [x] Data Integration (Historical, News, Financial Statements, Credit Card Spending, Sentiment Analysis)
# [x] Multi-Model Ensemble Predictions (XGBoost, LightGBM, CatBoost, LSTM/GRU)
# [x] Reinforcement Learning for Adaptive Trading Execution (PPO, A2C, DDPG)
# [x] Explainable AI with SHAP for Model Interpretability
# [x] Monte Carlo Simulations for Backtesting
# [x] Advanced Feature Engineering (Lagged Features, Seasonal Decomposition)
# [x] Market Regime Detection (K-Means, Gaussian Mixture Model)
# [x] Volatility Forecasting (GARCH Model)
# [x] Portfolio Optimization (Kelly Criterion, Risk Parity)
# [x] Real-Time Monitoring and Alerts for Risk Management
# [x] API Integration for Financial Data, Twitter Sentiment, and Alternative Data Sources
# [x] ChatGPT-4 Integration for Stock Market Q&A

import os
import pandas as pd
import numpy as np
import xgboost as xgb
import lightgbm as lgb
import catboost as cb
import tensorflow as tf
import shap
import torch
from sklearn.ensemble import StackingRegressor
from sklearn.linear_model import Ridge
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import MinMaxScaler
from arch import arch_model
from stable_baselines3 import PPO, A2C, DDPG
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose
import statsmodels.api as sm
import requests
from transformers import pipeline
from textblob import TextBlob
import openai
from kafka import KafkaProducer, KafkaConsumer
from flask import Flask
import dash
from dash import html, dcc
import subprocess
import sys

# ============================================================
# API KEYS CONFIGURATION
# ============================================================
API_KEYS = {
    'FMP': "AF1hEXX275aPc3MyL59dtl77vp0FkAuq",
    'Twitter': {
        'api_key': "D1nvknKFAiASmvsNmedPJLqYw",
        'secret_api': "AAePNnO0XkE1w6IACale6qmbggSEx2hdqAFs94HCliUdZq1aGd",
        'bearer_token': "AAAAAAAAAAAAAAAAAAAAAEQUwQEAAAAAT6NiQQR3YhX1AT0Q87%2F3LpkxZe0%3DjxjfRxA3beXPD9ukWpzxh3IAufnkPtSCmSiDtjpitMjfPPYJqZ"
    },
    'NewsAPI': "6ae54003dc074c33996d4648a4c748b0",
    'Quandl': "sLSKCCS3RPFWwKTLP1pT",
    'FRED': "92c1f38ebe08312f8b1e8a9dea6fbedc",
    'Predicto': "VZ19mf7DvVovUKW0E7PTYmzrJkQjkC5N5fMcWwOsglWPFzhSQPU8m77cb3d3k760",
    'OpenAI': "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"
}

BASE_URLS = {
    'FMP': "https://financialmodelingprep.com/api/v3",
    'Predicto': "https://api.predicto.com",
    'Twitter': "https://api.twitter.com/2",
    'NewsAPI': "https://newsapi.org/v2",
    'Quandl': "https://data.nasdaq.com",
    'FRED': "https://fred.stlouisfed.org/api"
}

# ============================================================
# INSTALL DEPENDENCIES
# ============================================================
def install_requirements():
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("All dependencies are installed.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred: {e}")

install_requirements()

# ============================================================
# FETCH DATA FUNCTIONS
# ============================================================
def fetch_data(url, params=None):
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error fetching data from {url}: {e}")
        return {}

def fetch_historical_data(symbol, start_date, end_date):
    url = f"{BASE_URLS['FMP']}/historical-price-full/{symbol}"
    params = {'from': start_date, 'to': end_date, 'apikey': API_KEYS['FMP']}
    data = fetch_data(url, params)
    return pd.DataFrame(data.get('historical', []))
# ============================================================
# KAFKA INTEGRATION FOR STREAMING
# ============================================================
producer = KafkaProducer(bootstrap_servers='localhost:9092')
consumer = KafkaConsumer('stock_data', group_id='stock_group', bootstrap_servers='localhost:9092')

def stream_data_to_kafka(data):
    producer.send('stock_data', value=data.to_json().encode('utf-8'))

def consume_realtime_data():
    for message in consumer:
        print(f"Received data: {message.value.decode('utf-8')}")

# ============================================================
# ARIMA FORECASTING USAGE
# ============================================================
def arima_forecasting(data, order=(5, 1, 0)):
    model = sm.tsa.ARIMA(data['close'], order=order)
    fit_model = model.fit()
    forecast = fit_model.forecast(steps=5)
    print(f"ARIMA Forecast: {forecast}")
    return forecast

# Example Usage
data = fetch_historical_data("AAPL", "2023-01-01", "2024-01-01")
arima_forecasting(data)

# ============================================================
# MULTI-AGENT REINFORCEMENT LEARNING SETUP
# ============================================================
class MultiAgentRL:
    def __init__(self, env):
        self.agents = [
            PPO('MlpPolicy', env, verbose=0),
            A2C('MlpPolicy', env, verbose=0),
            DDPG('MlpPolicy', env, verbose=0)
        ]

    def train_agents(self, steps=100000):
        for agent in self.agents:
            agent.learn(steps)

    def execute_trades(self, state):
        actions = [agent.predict(state)[0] for agent in self.agents]
        return np.mean(actions)

# ============================================================
# DASHBOARD SETUP USING DASH
# ============================================================
app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1('Stock Prediction Dashboard', style={'textAlign': 'center'}),
    dcc.Input(id='stock-symbol', value='AAPL', type='text'),
    html.Button('Submit', id='submit-button', n_clicks=0),
    html.Div(id='prediction-output'),
])

@app.callback(
    dash.dependencies.Output('prediction-output', 'children'),
    [dash.dependencies.Input('submit-button', 'n_clicks')],
    [dash.dependencies.State('stock-symbol', 'value')]
)
def update_output(n_clicks, symbol):
    if n_clicks > 0:
        data = fetch_historical_data(symbol, "2023-01-01", "2024-01-01")
        return f"Fetched data for {symbol}."

# ============================================================
# GARCH VOLATILITY FORECASTING
# ============================================================
def forecast_volatility(data, column='close'):
    model = arch_model(data[column], vol='Garch', p=1, q=1)
    try:
        garch_fit = model.fit(disp='off')
        data['volatility'] = garch_fit.conditional_volatility
    except Exception as e:
        print(f"Error during GARCH model fitting: {e}")
    return data

# ============================================================
# FEATURE ENGINEERING
# ============================================================
def advanced_feature_engineering(data, lags=[1, 2, 5, 10]):
    for lag in lags:
        data[f'close_lag_{lag}'] = data['close'].shift(lag)
    try:
        decomposition = seasonal_decompose(data['close'], model='multiplicative', period=365)
        data['trend'] = decomposition.trend
        data['seasonal'] = decomposition.seasonal
        data['residual'] = decomposition.resid
    except ValueError as e:
        print(f"Error during seasonal decomposition: {e}")
    scaler = MinMaxScaler()
    data[['close', 'volume']] = scaler.fit_transform(data[['close', 'volume']])
    return data

# ============================================================
# MARKET REGIME DETECTION
# ============================================================
def detect_market_regime(data):
    try:
        kmeans = KMeans(n_clusters=3, random_state=0).fit(data[['close', 'volume']].dropna())
        data['kmeans_regime'] = kmeans.labels_
        gmm = GaussianMixture(n_components=3, random_state=0).fit(data[['close', 'volume']].dropna())
        data['gmm_regime'] = gmm.predict(data[['close', 'volume']].dropna())
    except Exception as e:
        print(f"Error during market regime detection: {e}")
    return data

# ============================================================
# MONTE CARLO SIMULATIONS
# ============================================================
def monte_carlo_simulation(data, num_simulations=1000, time_horizon=252):
    last_price = data['close'].iloc[-1]
    returns = data['close'].pct_change().dropna()
    mean_return = returns.mean()
    std_dev = returns.std()

    simulation_df = pd.DataFrame()
    for i in range(num_simulations):
        price_series = [last_price]
        for _ in range(time_horizon):
            price = price_series[-1] * (1 + np.random.normal(mean_return, std_dev))
            price_series.append(price)
        simulation_df[i] = price_series

    plt.figure(figsize=(10, 5))
    plt.plot(simulation_df)
    plt.title('Monte Carlo Simulation for Stock Price Prediction')
    plt.xlabel('Day')
    plt.ylabel('Price')
    plt.show()
# ============================================================
# PORTFOLIO OPTIMIZATION
# ============================================================
def portfolio_optimization(returns):
    mean_return = returns.mean()
    variance = returns.var()
    kelly_fraction = mean_return / variance
    print(f"Optimal Fraction to Invest based on Kelly Criterion: {kelly_fraction}")
    
    inv_var = 1 / variance
    risk_parity_weights = inv_var / np.sum(inv_var)
    print(f"Risk Parity Weights: {risk_parity_weights}")

# ============================================================
# SENTIMENT ANALYSIS
# ============================================================
def sentiment_analysis(text):
    sentiment_pipeline = pipeline("sentiment-analysis")
    try:
        blob = TextBlob(text)
        sentiment_score = blob.sentiment.polarity
        sentiment_result = sentiment_pipeline(text)[0]
        return {
            'textblob_score': sentiment_score,
            'bert_sentiment': sentiment_result['label'],
            'bert_score': sentiment_result['score']
        }
    except Exception as e:
        print(f"Error during sentiment analysis: {e}")
        return {}

# ============================================================
# PREDICTO API INTEGRATION
# ============================================================
def fetch_predicto_insights(symbol, start_date, end_date):
    url = f"{BASE_URLS['Predicto']}/forecast"
    params = {
        'api_key': API_KEYS['Predicto'],
        'symbol': symbol,
        'start_date': start_date,
        'end_date': end_date
    }
    return fetch_data(url, params)

def integrate_predicto_insights(symbol, start_date, end_date, historical_data):
    predicto_data = fetch_predicto_insights(symbol, start_date, end_date)
    if predicto_data and 'forecast' in predicto_data:
        predicto_forecast = pd.DataFrame(predicto_data['forecast'])
        predicto_forecast['date'] = pd.to_datetime(predicto_forecast['date'])
        predicto_forecast.set_index('date', inplace=True)
        historical_data = historical_data.join(predicto_forecast, how='outer')
        print(f"Predicto Insights for {symbol} integrated successfully.")
    else:
        print(f"Failed to fetch Predicto insights for {symbol}.")
    return historical_data

# ============================================================
# GPT-4 INTEGRATION FOR STOCK Q&A
# ============================================================
def get_gpt_response(user_question):
    openai.api_key = API_KEYS['OpenAI']
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": user_question}],
            max_tokens=150
        )
        return response.choices[0].message["content"]
    except Exception as e:
        print(f"Error during GPT-4 response: {e}")
        return "Error: Unable to fetch response."

# ============================================================
# EXPLAINABLE AI WITH SHAP
# ============================================================
def explain_model(model, X_train):
    explainer = shap.Explainer(model)
    shap_values = explainer(X_train)
    shap.summary_plot(shap_values, X_train)

# ============================================================
# BACKTESTING MODULE
# ============================================================
from sklearn.metrics import mean_squared_error

def backtest_model(model, symbol, start_date, end_date):
    # Fetch historical data for the stock over the specified period
    historical_data = fetch_historical_data(symbol, start_date, end_date)
    X = historical_data[['close', 'volume']].values[:-1]
    y_actual = historical_data['close'].values[1:]

    # Generate predictions using the model
    y_pred = model.predict(X)

    # Calculate the Mean Squared Error (MSE) between predictions and actuals
    mse = mean_squared_error(y_actual, y_pred)
    print(f"Mean Squared Error (MSE) for {symbol}: {mse}")

    # Plot the actual vs. predicted prices for visualization
    plt.figure(figsize=(10, 5))
    plt.plot(historical_data.index[1:], y_actual, label='Actual Prices', alpha=0.7)
    plt.plot(historical_data.index[1:], y_pred, label='Predicted Prices', linestyle='--')
    plt.title(f'Backtesting Results for {symbol}')
    plt.xlabel('Date')
    plt.ylabel('Price')
    plt.legend()
    plt.show()

# ============================================================
# TRADING SIGNAL LOGIC
# ============================================================
def trading_signal(personality, sentiment):
    if personality == "Maverick" and sentiment['volatility'] > 0.7:
        print("High volatility detected! Consider buying options.")
    elif personality == "Manipulator" and sentiment['score'] < 0.4:
        print("Low sentiment! Prepare for a narrative shift.")
    else:
        print("Hold position.")

# ============================================================
# INSIDER AND SENATE TRADING DATA INTEGRATION
# ============================================================
def fetch_insider_trades(symbol):
    url = f"https://financialmodelingprep.com/api/v4/insider-trading?symbol={symbol}&apikey={API_KEYS['FMP']}"
    return fetch_data(url)

def fetch_senate_trades():
    url = f"https://financialmodelingprep.com/api/v4/senate-trading?apikey={API_KEYS['FMP']}"
    return fetch_data(url)
# ============================================================
# GNN-BASED CROSS-ASSET RELATIONSHIPS
# ============================================================
from torch_geometric.nn import GCNConv
from torch_geometric.data import Data

def build_cross_asset_graph(assets_data):
    # Create a graph where nodes are assets and edges represent correlations
    edge_index = torch.tensor([[0, 1], [1, 2]], dtype=torch.long)  # Example edges
    x = torch.tensor([[-1], [0], [1]], dtype=torch.float)  # Example node features
    data = Data(x=x, edge_index=edge_index)
    return data

def predict_asset_relationships(graph_data):
    model = GCNConv(1, 16)  # Define a GNN layer
    model.eval()
    with torch.no_grad():
        prediction = model(graph_data.x, graph_data.edge_index)
    return prediction

def use_gnn_for_predictions(data):
    graph = build_cross_asset_graph(data)
    predictions = predict_asset_relationships(graph)
    print(f"Graph-based predictions: {predictions}")

# ============================================================
# LSTM AND GRU MODEL INTEGRATION FOR TIME-SERIES FORECASTING
# ============================================================
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, GRU, Dense, Dropout

def create_lstm_model(input_shape):
    model = Sequential()
    model.add(LSTM(50, return_sequences=True, input_shape=input_shape))
    model.add(Dropout(0.2))
    model.add(LSTM(50, return_sequences=False))
    model.add(Dropout(0.2))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

def create_gru_model(input_shape):
    model = Sequential()
    model.add(GRU(50, return_sequences=True, input_shape=input_shape))
    model.add(Dropout(0.2))
    model.add(GRU(50, return_sequences=False))
    model.add(Dropout(0.2))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

def train_lstm_gru_models(data):
    X_train = data[['close', 'volume']].values.reshape(-1, 1, 2)
    y_train = data['close'].values

    lstm_model = create_lstm_model((X_train.shape[1], X_train.shape[2]))
    gru_model = create_gru_model((X_train.shape[1], X_train.shape[2]))

    lstm_model.fit(X_train, y_train, epochs=10, batch_size=32, verbose=1)
    gru_model.fit(X_train, y_train, epochs=10, batch_size=32, verbose=1)

    return lstm_model, gru_model

# ============================================================
# AUTO-ML PIPELINE WITH OPTUNA FOR HYPERPARAMETER OPTIMIZATION
# ============================================================
import optuna

def auto_ml_pipeline(data, target):
    def objective(trial):
        model_type = trial.suggest_categorical('model', ['RandomForest', 'XGBoost', 'LightGBM'])
        if model_type == 'RandomForest':
            from sklearn.ensemble import RandomForestRegressor
            model = RandomForestRegressor(n_estimators=trial.suggest_int('n_estimators', 50, 300))
        elif model_type == 'XGBoost':
            model = xgb.XGBRegressor(learning_rate=trial.suggest_loguniform('learning_rate', 0.01, 0.3))
        else:
            model = lgb.LGBMRegressor(num_leaves=trial.suggest_int('num_leaves', 20, 150))
        model.fit(data, target)
        return model.score(data, target)

    study = optuna.create_study(direction='maximize')
    study.optimize(objective, n_trials=50)
    return study.best_trial

# ============================================================
# METRICS LOGGING AND ENHANCED BACKTESTING
# ============================================================
from sklearn.metrics import r2_score

def calculate_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    sharpe_ratio = np.mean(y_pred - y_true) / np.std(y_pred - y_true)
    sortino_ratio = np.mean(y_pred - y_true) / np.std([x for x in (y_pred - y_true) if x < 0])
    max_drawdown = np.min(y_pred / np.maximum.accumulate(y_pred) - 1)

    print(f"MSE: {mse}")
    print(f"Sharpe Ratio: {sharpe_ratio}")
    print(f"Sortino Ratio: {sortino_ratio}")
    print(f"Max Drawdown: {max_drawdown}")

    return mse, sharpe_ratio, sortino_ratio, max_drawdown

def enhanced_backtest(model, data):
    X = data[['close', 'volume']].values[:-1]
    y_actual = data['close'].values[1:]

    y_pred = model.predict(X)
    mse, sharpe, sortino, drawdown = calculate_metrics(y_actual, y_pred)

    plt.figure(figsize=(10, 5))
    plt.plot(data.index[1:], y_actual, label='Actual Prices')
    plt.plot(data.index[1:], y_pred, label='Predicted Prices', linestyle='--')
    plt.title('Enhanced Backtesting Results')
    plt.xlabel('Date')
    plt.ylabel('Price')
    plt.legend()
    plt.show()

# ============================================================
# MAIN SCRIPT EXECUTION
# ============================================================
if __name__ == "__main__":
    # Fetch historical data
    symbol = "AAPL"
    data = fetch_historical_data(symbol, "2023-01-01", "2024-01-01")

    # Train LSTM and GRU models
    lstm_model, gru_model = train_lstm_gru_models(data)

    # Perform enhanced backtesting with metrics logging
    enhanced_backtest(lstm_model, data)

    # Start the Dash app
    app.run(host="127.0.0.1", port=8050, debug=True)
# ============================================================
# COMPARING MODEL PREDICTIONS WITH PREDICTO FORECAST
# ============================================================
def compare_and_fine_tune(model, X_test, y_test, symbol, start_date, end_date):
    # Step 1: Get predictions from both your model and Predicto
    model_predictions = model.predict(X_test)
    predicto_forecast = fetch_predicto_insights(symbol, start_date, end_date)

    if predicto_forecast and 'forecast' in predicto_forecast:
        predicto_predictions = [entry['close'] for entry in predicto_forecast['forecast']]
        
        # Ensure both arrays are aligned in size
        min_len = min(len(model_predictions), len(predicto_predictions))
        model_predictions = model_predictions[:min_len]
        predicto_predictions = predicto_predictions[:min_len]

        # Step 2: Calculate error between the two sets of predictions
        mse_error = mean_squared_error(predicto_predictions, model_predictions)
        print(f"Mean Squared Error between your model and Predicto: {mse_error}")

        # Step 3: Fine-tune the model if error exceeds a threshold
        if mse_error > 0.01:  # Threshold can be adjusted
            print("Error threshold exceeded. Fine-tuning the model...")
            model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001), loss='mse')
            model.fit(X_test, y_test, epochs=10, verbose=1)
        else:
            print("No fine-tuning required. Model is well-aligned with Predicto.")
    else:
        print(f"Failed to fetch Predicto forecast for {symbol}.")

# ============================================================
# AUTOMATED BACKTESTING AND METRICS LOGGING
# ============================================================
from backtesting import Backtest, Strategy

class MyStrategy(Strategy):
    def init(self):
        self.signal = self.I(lambda x: x > 0, self.data.Close)  # Dummy signal

    def next(self):
        if self.signal > 0:
            self.buy()
        elif self.signal < 0:
            self.sell()

def run_backtest(data):
    bt = Backtest(data, MyStrategy, cash=10000, commission=.002)
    stats = bt.run()
    print(stats[['Sharpe Ratio', 'Sortino Ratio', 'Max Drawdown']])

# Example usage of backtesting
historical_data = fetch_historical_data("AAPL", "2023-01-01", "2024-01-01")
run_backtest(historical_data)

# ============================================================
# FINAL WRAP-UP AND SUMMARY
# ============================================================
print("All modules executed successfully. Your stock prediction system is fully operational!")

# Optional: Example of streaming data processing
try:
    print("Starting real-time data monitoring...")
    stream_monitoring()  # This runs indefinitely to monitor streams
except KeyboardInterrupt:
    print("Real-time monitoring stopped by user.")

# End of Script